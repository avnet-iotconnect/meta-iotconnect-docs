Device Certificates will be placed into this folder through onboarding script
