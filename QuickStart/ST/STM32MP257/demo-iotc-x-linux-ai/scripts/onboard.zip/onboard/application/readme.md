contents inside folder `application` are used to replace contents inside `/usr/iotc/app`
