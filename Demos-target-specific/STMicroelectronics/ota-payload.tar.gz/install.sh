#!/bin/bash

# Define directories for the OTA update
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
APPLICATION_PAYLOAD_DIR="$SCRIPT_DIR/application"
LOCAL_DATA_PAYLOAD_DIR="$SCRIPT_DIR/local_data"
DATA_PAYLOAD_DIR="$LOCAL_DATA_PAYLOAD_DIR/data"  # New data folder in the payload

# Directories for AI updates
X_LINUX_AI_PAYLOAD_DIR="$SCRIPT_DIR/x-linux-ai"
IMAGE_CLASS_PAYLOAD_DIR="$X_LINUX_AI_PAYLOAD_DIR/image-classification"
OBJECT_DETECT_PAYLOAD_DIR="$X_LINUX_AI_PAYLOAD_DIR/object-detection"
POSE_EST_PAYLOAD_DIR="$X_LINUX_AI_PAYLOAD_DIR/pose-estimation"
SEM_SEG_PAYLOAD_DIR="$X_LINUX_AI_PAYLOAD_DIR/semantic-segmentation"

# Define installed directories
APPLICATION_INSTALLED_DIR="/usr/iotc/bin/iotc-python-sdk"
LOCAL_DATA_INSTALLED_DIR="/usr/iotc/local/data"
X_LINUX_AI_INSTALLED_DIR="/usr/local/x-linux-ai"
IMAGE_CLASS_INSTALLED_DIR="$X_LINUX_AI_INSTALLED_DIR/image-classification"
OBJECT_DETECT_INSTALLED_DIR="$X_LINUX_AI_INSTALLED_DIR/object-detection"
POSE_EST_INSTALLED_DIR="$X_LINUX_AI_INSTALLED_DIR/pose-estimation"
SEM_SEG_INSTALLED_DIR="$X_LINUX_AI_INSTALLED_DIR/semantic-segmentation"

# Backup directories
BACKUP_DIR="/tmp/.ota/backup"

# Create a backup of existing files
mkdir -p "$BACKUP_DIR"
cp -va "$APPLICATION_INSTALLED_DIR"/* "$BACKUP_DIR/"
cp -va "$LOCAL_DATA_INSTALLED_DIR"/* "$BACKUP_DIR/"
cp -va "$X_LINUX_AI_INSTALLED_DIR"/* "$BACKUP_DIR/"

# Function to update a directory
update_directory() {
    local payload_dir="$1"
    local target_dir="$2"

    if [ -d "$payload_dir" ]; then
        cp -va "$payload_dir"/* "$target_dir/"
        echo "Updated $target_dir with files from $payload_dir"
    fi
}

# Update application files
update_directory "$APPLICATION_PAYLOAD_DIR" "$APPLICATION_INSTALLED_DIR"

# Update local data files
update_directory "$DATA_PAYLOAD_DIR" "$LOCAL_DATA_INSTALLED_DIR"

# Update AI-related files
update_directory "$IMAGE_CLASS_PAYLOAD_DIR" "$IMAGE_CLASS_INSTALLED_DIR"
update_directory "$OBJECT_DETECT_PAYLOAD_DIR" "$OBJECT_DETECT_INSTALLED_DIR"
update_directory "$POSE_EST_PAYLOAD_DIR" "$POSE_EST_INSTALLED_DIR"
update_directory "$SEM_SEG_PAYLOAD_DIR" "$SEM_SEG_INSTALLED_DIR"

# Check if update was successful
if [ $? -eq 0 ]; then
    echo "install.sh completed successfully."
else
    >&2 echo "install.sh encountered errors."
    exit 1
fi

