#!/bin/bash

# Define directories for the OTA update
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
APPLICATION_PAYLOAD_DIR="$SCRIPT_DIR/application"
LOCAL_DATA_PAYLOAD_DIR="$SCRIPT_DIR/local_data"
DATA_PAYLOAD_DIR="$LOCAL_DATA_PAYLOAD_DIR/data"  # New data folder in the payload

# Define the installed directories
APPLICATION_INSTALLED_DIR="/usr/iotc/bin/iotc-python-sdk"
LOCAL_DATA_INSTALLED_DIR="/usr/iotc/local/data"  # Target location for the data folder

# Backup directories
BACKUP_DIR="/tmp/.ota/backup"

# Create a backup of existing files
mkdir -p "$BACKUP_DIR"
cp -va "$APPLICATION_INSTALLED_DIR"/* "$BACKUP_DIR/"
cp -va "$LOCAL_DATA_INSTALLED_DIR"/* "$BACKUP_DIR/"

# Function to update a directory
update_directory() {
    local payload_dir="$1"
    local target_dir="$2"

    if [ -d "$payload_dir" ]; then
        cp -va "$payload_dir"/* "$target_dir/"
        echo "Updated $target_dir with files from $payload_dir"
    fi
}

# Update application files
update_directory "$APPLICATION_PAYLOAD_DIR" "$APPLICATION_INSTALLED_DIR"

# Transfer 'data' folder contents to /usr/iotc/local/data/
if [ -d "$DATA_PAYLOAD_DIR" ]; then
    update_directory "$DATA_PAYLOAD_DIR" "$LOCAL_DATA_INSTALLED_DIR"
    echo "Transferred 'data' folder to /usr/iotc/local/data/"
fi

# Check if update was successful
if [ $? -eq 0 ]; then
    echo "install.sh completed successfully."
else
    >&2 echo "install.sh encountered errors."
    exit 1
fi

